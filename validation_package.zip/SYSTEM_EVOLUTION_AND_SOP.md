# Goldenset 验证系统 — 演化进程与最终 SOP

## 一、系统演化进程

### Phase 1: 原始提取 (口径 A)

**状态**: 35 篇论文 → DeepSeek 全文提取 + Qwen VLM 图像提取 → Schema Mapping → Mydata 格式

**指标**: recall 88%, precision 27%, field_accuracy 75%

**主要问题**:
- pH 全被 Schema Mapping 自动推断 (0 条从原文提取)
- 原子序数由 Schema Mapping LLM 直接输出,经常算错
- 形态/载体信息完全缺失 (不在数据点 evidence 中)
- 负载量几乎全空
- 催化剂名 Unicode 下标导致匹配失败

### Phase 2: 后处理修正 (口径 B)

**2.1 pH 正则提取** (`04_enrich_ph_from_evidence.py`)
- 正则匹配电解质信号: 0.1M NaOH→13, 1M KOH→14, 0.5M K2SO4→7
- 同文档传播到图像记录
- Bug: `1M NaOH` 正则误匹配 `0.1M` 中的 `.1` → 修复顺序
- 效果: pH 匹配率 18%→55%, 后修复到 83%→98%

**2.2 催化剂拆解+周期表** (`goldenset_decompose_catalyst.py`)
- 规则拆解催化剂名 → active_metal, modifier, support
- 周期表查元素 → 原子序数
- Bug: Co 被误认为 C(碳), Fe2O3 活性金属被识别为 O(氧)
- 效果: 活性金属原子序数 87%→100%

**2.3 Unicode 归一化**
- `str.translate(SUB_MAP)` 将 ₀₁₂₃₄₅₆₇₈₉→0123456789
- 效果: +24 匹配行

**2.4 LLM 形态/载体提取** (`run_llm_morphology_v2.py`)
- 每文档 1 次 LLM 调用,从 Experimental 段提取
- Role/Task/Rules/Output 结构,约束词表
- 后处理同义词兜底: flake→nanosheet, nanofiber→nanowire
- VLM 读 SEM 图像补充 (226 张图)
- 效果: 形态/载体 flags 1412→1789 (+377)

**2.5 LLM 负载量提取**
- 第 1 轮: 发现 gold 负载量 = 改性元素质量分数 wt%
- 第 2 轮: 从 Experimental+SI 提取改性元素 wt% (ICP-OES/EDS)
- 纯催化剂本地填 0
- 效果: 从全空 → 7 个催化剂有数据

**2.6 DFT 改性方式分类** (`extract_modification_type.py`)
- 从 DFT/Computational 段判断掺杂(替换晶格)还是负载(表面吸附)
- 效果: 35 个催化剂分类,大部分 high confidence

**2.7 匹配算法改进**
- 原匹配: (催化剂名, 电势, FE) 三层过滤, 选 FE 最近
- 问题: 同一论文中不同催化剂 FE 碰巧接近, 串到错误记录
- 改进: FE 差<0.03 时, 优先选 raw catalyst_name_raw 元素重叠高的候选
- 效果: 13 条匹配串行被修正

### 版本演进映射

| 版本 | 新增内容 | 累计效果 |
|------|---------|---------|
| raw (口径A) | schema_mapped_normalized_records.json | recall 88%, precision 27%, field_acc 75% |
| v3 | pH正则 + loading support | pH 55%→83%, loading 开始有数据 |
| v4 | 催化剂拆解+周期表 | 活性金属Z 87%→100% |
| v7 | LLM形态/载体 + DFT改性方式 + VLM SEM | flags +377, 改性方式分类完成 |
| v8 | VLM形态图文合并 | 形态覆盖率最大化 |
| v11 | per-row modifier raw record回填 | 改性Z per-row修正 |
| **v13** | HCl pH修正 + 活性组分匹配放宽 | **pH 98%, 最终版本** |

**最终产物文件**: `final_v13_ph_fixed.json`

### Phase 3: 评估框架升级

**从 "匹配率" → "逐行可审计结论"**
- 每条记录逐字段判定: content_correct / gold_likely_wrong / extraction_likely_wrong / numeric_equivalent / multi_condition_not_error / etc.
- 三份输出: .md 总结 + .xlsx 审计表 + .json 证据链

---

## 二、最终系统 SOP

### 2.1 系统定位

对 35 篇硝酸盐还原电催化文献进行结构化数据提取,与人工标注 gold standard 对比。评估框架输出证据链完整的逐行可审计结论。

### 2.2 数据流

```
Mydata22.0_1√(1).xlsx (183 gold rows)
        │
schema_mapped_normalized_records.json (1029 extraction rows)
        │
        ├── 04_enrich_ph_from_evidence.py          pH 修正
        ├── goldenset_decompose_catalyst.py         原子序数
        ├── Unicode 归一化 (内联)                    催化剂匹配
        ├── run_llm_morphology_v2.py                形态/载体
        ├── extract_loading_support.py               载体材料
        ├── extract_modifier_mass_fraction.py        负载量
        ├── extract_modification_type.py             改性方式
        ├── run_vlm_morph.py                         VLM SEM形态
        ├── per-row modifier fix                     改性Z按行
        ├── HCl/K2SO4 pH fix                         pH精细修正
        │
        ▼
final_v13_ph_fixed.json
        │
        ▼
build_final_judgement.py ──→ final_judgement_summary.md
                         ──→ final_judgement_rows.xlsx
                         ──→ final_judgement_rows.json
```

### 2.3 字段提取规则速查表

| 字段 | 来源 | 方法 | 容差 |
|------|------|------|------|
| 催化剂名 | Schema Mapping | Unicode→ASCII, 后缀别名, 双向包含 | — |
| FE | Schema Mapping | 直接对比 | ±0.12 |
| 电势 | VLM+文本 | 直接对比 | ±0.001 (精密) / ±0.05 (宽松) |
| 活性金属Z | 催化剂拆解 | 名→active_metal→周期表 | 整数精确 |
| 改性金属Z | 催化剂拆解+raw record | 名→modifier+raw回填→周期表 | 整数精确 |
| 载体Z | LLM载体材料 | 载体材料名→元素→周期表 | 整数精确 |
| NO3 | Schema Mapping | 直接对比 | 相对<10% |
| pH | 正则+传播 | 电解质信号+同doc传播 | ±0.5 |
| 改性方式 | DFT LLM | 掺杂(1):替换晶格, 负载(0):表面沉积 | 整数精确 |
| 负载量 | LLM 提取 | 改性元素 wt% (ICP/EDS) | ±0.003 |
| 形态 flags | LLM+VLM | 图文双路合并,词表约束 | 布尔 |
| 载体 flags | LLM | 载体材料→flag | 布尔 |

### 2.4 匹配方法

```
Gold行 → ① 催化剂名归一化(双向包含) → Extraction候选
       → ② 电势 ±0.05V                 → 候选缩小
       → ③ FE ±0.12                    → 候选排序
       → ④ 元素重叠优先(FE差<0.03时)     → 最佳匹配
```

### 2.5 判定枚举

| 判定 | 含义 |
|------|------|
| `content_correct` | 双方一致 |
| `gold_likely_wrong` | 证据支持 extraction, gold 有误 |
| `extraction_likely_wrong` | 证据支持 gold, extraction 有误 |
| `numeric_equivalent` | 数值等价(VLM精度/子集匹配) |
| `multi_condition_not_error` | 多实验条件,不算错 |
| `unit_conversion_difference` | 单位换算差异 |
| `binding_uncertain` | 匹配串行,无法判定 |
| `disputed_or_review` | 需人工复核 |
| `extraction_missing` | 提取无数据 |

### 2.6 LLM 调用统计

| 步骤 | 调用次数 | 模型 |
|------|---------|------|
| 原始文本提取 | 35 | deepseek-v4-flash |
| Qwen VLM 图像 | 507 | qwen3.7-plus |
| Schema Mapping | 55 | deepseek-v4-flash |
| 形态/载体 LLM | 34 | deepseek-chat |
| 负载量 LLM | 34×2 | deepseek-chat |
| 改性方式 DFT LLM | 21 | deepseek-chat |
| VLM SEM 形态 | 226 | qwen-vl-max |
| **总计** | **~950** | |

### 2.7 输出产物

| 文件 | 用途 |
|------|------|
| `final_v13_ph_fixed.json` | 最终 mapped records |
| `final_judgement_summary.md` | 人读总结报告 |
| `final_judgement_rows.xlsx` | 逐行可筛选审计表 |
| `final_judgement_rows.json` | 证据链完整 JSON |
| `full_dispute_audit.xlsx` | 逐行争议审计 |
| `NO3_audit_table.xlsx` | NO3 专项审计 |
| `GOLDENSET_SOP.md` | 字段提取 SOP |

### 2.8 已知陷阱

1. **Unicode 下标**: ₃₄₁₂ 不转换 → 归一化后完全不同
2. **正则顺序**: 0.1M 必须在 1M 前面
3. **负载量 = 改性元素 wt%**: 不是总负载量
4. **SI 文件**: EDS 数据多在 SI
5. **复合图**: VLM 看复合 figure 返回 unknown
6. **NO3-N 换算**: NaNO3 vs NO3-N 差 6 倍
7. **匹配串行**: 同论文不同催化剂 FE 接近时,用元素重叠优先
8. **Gold 标注不一致**: 改性方式标准混乱, pH 标注错误, 负载量用计算值
