# Goldenset Final Judgement Report

## 1. Summary

- gold_rows_total: 310
- matched_rows: 286
- unmatched_rows: 24
- content_correct_rows: 10
- gold_likely_wrong_rows: 170
- extraction_likely_wrong_rows: 33
- disputed_or_review_rows: 27
- numeric_equivalent_rows: 46

## 2. Field Statistics

### FE: ok=286/286 (100%)

| Judgement | Count |
|-----------|-------|
| content_correct | 286 |

**Main reasons:**
- : 286

### 电势: ok=247/286 (86%)

| Judgement | Count |
|-----------|-------|
| content_correct | 247 |
| numeric_equivalent | 39 |

**Main reasons:**
- : 247
- vlm_reading_precision: 39

### 活性金属Z: ok=279/286 (99%)

| Judgement | Count |
|-----------|-------|
| content_correct | 279 |
| extraction_likely_wrong | 4 |
| extraction_missing | 3 |

**Main reasons:**
- : 279
- atomic_number_mismatch: 4
- no_value: 3

### 改性金属Z: ok=231/286 (92%)

| Judgement | Count |
|-----------|-------|
| content_correct | 231 |
| extraction_missing | 35 |
| extraction_likely_wrong | 12 |
| binding_uncertain | 8 |

**Main reasons:**
- : 231
- no_value: 35
- atomic_number_mismatch: 12
- wrong_catalyst_matched: 8

### 载体Z: ok=194/286 (87%)

| Judgement | Count |
|-----------|-------|
| content_correct | 194 |
| extraction_missing | 63 |
| extraction_likely_wrong | 24 |
| binding_uncertain | 5 |

**Main reasons:**
- : 194
- no_value: 63
- atomic_number_mismatch: 24
- wrong_catalyst_matched: 5

### NO3: ok=177/286 (84%)

| Judgement | Count |
|-----------|-------|
| content_correct | 177 |
| extraction_missing | 75 |
| multi_condition_not_error | 29 |
| unit_conversion_difference | 5 |

**Main reasons:**
- : 177
- no_value: 75
- multi_concentration_testing: 29
- NO3-N_vs_NaNO3: 5

### pH: ok=225/286 (80%)

| Judgement | Count |
|-----------|-------|
| content_correct | 225 |
| gold_likely_wrong | 40 |
| disputed_or_review | 17 |
| extraction_missing | 4 |

**Main reasons:**
- : 225
- electrolyte_supports_extraction: 40
- ph_mismatch_no_evidence: 17
- no_value: 4

### 改性方式: ok=98/286 (36%)

| Judgement | Count |
|-----------|-------|
| gold_likely_wrong | 175 |
| content_correct | 98 |
| extraction_missing | 13 |

**Main reasons:**
- gold_marks_pure_as_modified: 121
- : 98
- gold_missed_modifier: 54
- no_value: 13

### 负载量: ok=92/286 (64%)

| Judgement | Count |
|-----------|-------|
| extraction_missing | 142 |
| content_correct | 92 |
| disputed_or_review | 52 |

**Main reasons:**
- no_value: 142
- loading_value_differs: 52
- pure_catalyst: 48
- : 44

### 活性组分: ok=237/286 (87%)

| Judgement | Count |
|-----------|-------|
| content_correct | 237 |
| numeric_equivalent | 35 |
| extraction_missing | 13 |
| disputed_or_review | 1 |

**Main reasons:**
- : 237
- active_component_subset: 35
- no_value: 13
- active_component_mismatch: 1
