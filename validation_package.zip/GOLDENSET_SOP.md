# Goldenset 验证系统 SOP

## 一、系统定位

对 35 篇硝酸盐还原电催化文献进行结构化数据提取，与人工标注 gold standard 对比，量化提取准确度。

**原则**：所有改进在 `goldenset_nitrate_all/` 下运行，不污染竞赛管线。

## 二、数据流

```
Mydata22.0_1√(1).xlsx (310 gold rows)
        │
schema_mapped_normalized_records.json (1029 extraction rows, 原始口径A)
        │
        ├── pH 正则修正 (04_enrich_ph_from_evidence.py)
        ├── 催化剂拆解+周期表 (goldenset_decompose_catalyst.py)
        ├── Unicode归一化 (内联)
        ├── LLM 形态/载体提取 (run_llm_morphology_v2.py)
        ├── LLM 载体材料+负载量 (extract_loading_support.py)
        ├── LLM 负载量=改性元素wt% (extract_modifier_mass_fraction.py)
        ├── DFT 改性方式分类 (extract_modification_type.py)
        ├── VLM SEM 形态分类 (run_vlm_morph.py)
        │
        ▼
final_v8_morph_merged.json (后处理后, 口径B)
        │
        ▼
final_evaluation_report.json (评估报告)
full_dispute_audit.xlsx (逐行审计表)
```

## 三、字段提取规则

### 3.1 核心标识（催化剂名/活性组分）
- **来源**: Schema Mapping 原始输出
- **归一化**: `str.translate(SUB_MAP)` 将 ₀₁₂₃₄₅₆₇₈₉→0123456789, \xa0→空格
- **后缀别名**: NWs/C→/PC, PHNSs→去除, NAs→去除
- **匹配**: 双向包含匹配 (gold名 in extr名 OR extr名 in gold名)

### 3.2 FE（法拉第效率）
- **来源**: Schema Mapping 原始输出
- **Tolerance**: ±0.12 (绝对值)
- **判错标准**: |gold_FE - extr_FE| ≥ 0.12

### 3.3 电势（V vs. RHE）
- **来源**: VLM 读图 + 文本提取
- **Tolerance**: ±0.001V 精确匹配, ±0.05V 宽松匹配
- **常见问题**: VLM 从图表轴读取有 0.01-0.05V 偏差

### 3.4 活性金属/改性金属/载体 原子序数
- **提取方法**: 
  1. 催化剂名拆解 → active_metal, modifier, support
  2. 周期表查元素 → 原子序数
- **拆解规则** (优先级):
  1. 名中含数字: "Ag1.5Co/CC" → 改性=Ag, 活性=Co
  2. 前缀+连字符: "La-Co3O4" → 改性=La, 活性=Co
  3. @ 分隔: "Cu@ZnO" → 改性=Cu, 活性=Zn
  4. 后缀支持: /CC→载体C(6), /CF→Cu(29), /NF→Ni(28), /TP→Ti(22)
- **常见错误**: 
  - Co 被误认为 C (碳, Z=6) — 已通过两字母元素优先匹配修复
  - Fe2O3 活性金属被识别为 O — 已通过非金属排除修复

### 3.5 硝酸盐浓度（NO3）
- **提取方法**: Schema Mapping 从 electrolyte 字段提取
- **Tolerance**: 相对偏差 < 10% (|gold-extr|/gold < 0.1)
- **常见不匹配原因**:
  1. 多浓度测试 (同一催化剂同一电势下论文测试了多个浓度)
  2. 单位换算差异 (NO3-N vs NaNO3, 差 6.07 倍)
- **判错标准**: 
  - 多浓度测试 → 不计错
  - 单位换算差异 → 不计错
  - 其他 → 需人工判定

### 3.6 pH
- **提取方法**: 
  1. 正则匹配电解质信号: 0.1M NaOH→13, 1M KOH→14, 0.5M K2SO4→7
  2. 同催化剂/同文档传播
- **正则顺序**: 0.xM 规则必须在 1M 规则前面 (防止 '1' 误匹配 '0.1' 中的 '.1')
- **Tolerance**: ±0.5
- **判错标准**: 
  - 电解质明确支持提取值 → gold 错, 不计错
  - 无电解质信号 → 无法判定, 不计错

### 3.7 改性方式（负载0/掺杂1）
- **提取方法**: DFT 段落 LLM 分类
- **掺杂(=1)**: substitutional doping, 替换晶格原子, XRD峰移
- **负载(=0)**: surface decoration, 沉积在表面, TEM显示颗粒
- **判错标准**: Gold 标记纯催化剂为"改性" → 不计错

### 3.8 负载量（改性元素质量分数 wt%）
- **提取方法**: LLM 从 Experimental + SI 提取改性元素 wt% (ICP-OES/EDS)
- **纯催化剂**: 无改性元素 → 本地填写 0
- **判错标准**: Gold 值为自行换算(原文不存在) → 不计错

### 3.9 载体/形貌 Flags
- **形态提取**: LLM (文本) + VLM (SEM图), 图文双路合并
- **载体提取**: LLM 返回材料名 → 查表得 flag
- **标准词表**: 
  - 形态: nanowire, nanosheet, nanobelt, nanotube, nanorod, nanoparticle, nanosphere
  - 载体: foam, mesh, fiber, foil
- **后处理**: 同义词映射 (flake→nanosheet, nanofiber→nanowire, nanoribbon→nanobelt)

## 四、评估方法

### 4.1 匹配逻辑

```
Gold行 → ① 催化剂名归一化(双向包含) → Extraction候选
       → ② 电势 ±0.05V                 → 候选缩小
       → ③ FE ±0.12                    → 最佳匹配行
```

### 4.2 两套口径

| | 口径 A (全量) | 口径 B (后处理) |
|------|-------------|----------------|
| Gold | Mydata Excel (310 rows) | gold_rows_fixed.json (183 rows) |
| Extraction | schema_mapped_normalized_records.json | final_v8_morph_merged.json |
| 匹配 | greedy matching | triplet 严格过滤 |
| 用途 | 全量召回/字段对齐审计 | 后处理改进验证 |

### 4.3 判错标准

| 情况 | 是否计错 |
|------|---------|
| Gold 标注纯催化剂为"改性" | NO (gold问题) |
| Gold 用自行换算值 | NO (gold问题) |
| 多浓度测试 vs Gold 单值 | NO (系统差异) |
| 单位换算差异 | NO (系统差异) |
| 电解质明确, Gold 标错 pH | NO (gold问题) |
| 提取明显错误 | YES |
| VLM 读数偏差 > 0.1V | YES |
| 改性元素/载体未识别 | YES |

## 五、运行步骤

### 准备
```bash
# Gold 文件和 MinerU 输出在:
E:\fluent_agent\goldenset\Mydata22.0_1√(1).xlsx
E:\fluent_agent\goldenset\goldenset_results_small_66_ok\results_small\

# API 设置
检查 .env: DEEPSEEK_API_KEY, QWEN_API_KEY
检查代理: HTTP_PROXY/HTTPS_PROXY — 如指向 127.0.0.1:9 需清空
```

### 后处理步骤 (全部可在 goldenset 目录下独立运行)
```bash
# 1. pH 修正
python 04_enrich_ph_from_evidence.py --input schema_mapping_input_records.json --output ph_enriched.json

# 2. 催化剂拆解
python goldenset_decompose_catalyst.py --input ph_and_loading_fixed_v3.json --output catalyst_decomposed_v4.json

# 3. LLM 形态/载体 (34次调用)
python run_llm_morphology_v2.py

# 4. LLM 负载量 (34次调用)
python extract_loading_support.py

# 5. LLM 改性元素wt% (34次调用)
python extract_modifier_mass_fraction.py

# 6. DFT 改性方式 (21次调用)
python extract_modification_type.py

# 7. VLM SEM 形态 (226次调用, 可选)
python run_vlm_morph.py

# 8. 评估
python final_evaluation_report.py
python full_dispute_audit.py
```

### LLM 成本
| 步骤 | 调用次数 | 模型 |
|------|---------|------|
| 形态/载体 | 34 | deepseek-chat |
| 负载量(第1轮) | 34 | deepseek-chat |
| 负载量(第2轮) | 34 | deepseek-chat |
| 改性方式(DFT) | 21 | deepseek-chat |
| VLM SEM | 226 | qwen-vl-max |
| **合计** | ~350 | |

## 六、已知陷阱

1. **Unicode 下标**: ₃₄₁₂\xa0 不转换会导致归一化后字符串完全不同
2. **正则顺序**: 0.1M 规则必须放在 1M 前面, 否则 '1' 会误匹配 '0.1' 中的 '.1'
3. **负载量定义**: Gold 的"负载量"实际是"改性元素质量分数 wt%", 不是总负载量
4. **Gold MySQL**: 183 行 vs 310 evaluation units — 评估框架内部有展开逻辑
5. **SI 文件**: EDS 数据多在 SI 中, 正文 Experimental 段不一定有
6. **复合图**: VLM 看复合 figure 返回 unknown 概率高, 需取单 panel
7. **NO3-N 换算**: NaNO3 vs NO3-N 差 6.07 倍, 需统一换算标准

## 七、产物索引

| 文件 | 用途 |
|------|------|
| `final_v8_morph_merged.json` | 最终 mapped records |
| `final_evaluation_report.json` | 全量+口径B 评估数据 |
| `full_dispute_audit.xlsx` | 逐行审计表 (all_fields + Summary) |
| `NO3_audit_table.xlsx` | NO3 逐行审计 |
| `NO3_mismatch_report.md` | NO3 分析报告+SOP |
| `dispute_evidence.json` | 争议证据 |
| `vlm_morphology_results.json` | VLM 形态分类结果 |
| `modification_type_per_catalyst.json` | DFT 改性方式分类 |
| `loading_synthesis_calc.json` | 负载量计算结果 |
| `morphology_per_catalyst_v2.json` | 形态分类结果 |
