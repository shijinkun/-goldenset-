# Goldenset 验证 — 最终报告

## 一、总体结果

| 指标 | 值 |
|------|-----|
| Gold 总行数 | 310 |
| 提取总行数 | 1029 |
| 匹配行数 | 286 (92.3%) |
| 未匹配行数 | 24 |
| 完全正确行 | 10 |
| Gold 标注错误行 | 170 |
| 提取错误行 | 33 |
| 数值等价行 | 46 |
| 需人工复核行 | 27 |

### 字段级统计

| 字段 | OK | 不匹配 | 主要不匹配原因 |
|------|-----|--------|---------------|
| 催化剂名 | 286 | 0 | — |
| FE | 286 | 0 | — |
| 活性金属Z | 282 | 4 | 活性金属识别差异 |
| 电势 | 257 | 29 | VLM读数精度 (20), 电势偏差 (9) |
| 改性金属Z | 241 | 45 | Gold标注差异 (33), 改性元素识别 (12) |
| 载体Z | 220 | 66 | 载体元素未识别 (42), Gold标注差异 (24) |
| NO3 | 198 | 88 | 多浓度测试 (43), 单位换算 (12), 需证据 (33) |
| pH | 243 | 37 | Gold标错 (22), 无电解质信号 (15) |
| 改性方式 | 101 | 185 | Gold纯催化剂标为改性 (119), Gold漏标 (66) |
| 负载量 | 85 | 201 | Gold计算值 (147), 提取无数据 (54) |
| 活性组分 | 258 | 28 | Gold含改性剂/载体 (22), 匹配问题 (6) |

> 注: 形态/载体 flags 匹配率在 88-100%, 此处仅列核心字段。

---

## 二、24 条未匹配行 — 逐条原因

| # | Gold催化剂 | 电势 | FE | 未匹配原因 |
|---|-----------|------|-----|-----------|
| 1-12 | Co3O4 (对比催化剂) | -1.0~0.4V | 0.60~1.0 | 提取中无纯"Co3O4"记录,均为"Co3O4/CC"等带载体名 |
| 13-16 | Fe2O3 (对比催化剂) | -1.0~0.6V | 0.34~0.94 | 同上,提取中为"Fe2O3/CC" |
| 17 | CuO IHNSs | -1.0 | 0.515 | 电势偏差>0.05V,提取最近值为-0.5V |
| 18 | Fe-V2O5 | -0.7 | 0.4669 | FE在tolerance边缘,提取最近FE=0.58 |
| 19 | Fe3O4/SS | -0.2 | 0.7316 | 提取中该催化剂无-0.2V附近的记录 |
| 20 | P25-TiO2 | -1.2 | 0.3913 | 催化剂名不匹配(提取为"P25-600"等) |
| 21 | Ru/Cu2O | 0.0 | 0.1913 | 电势为0V,提取中该催化剂记录电势范围不同 |

**根因**: 12+4 条是 gold 用纯物质名(如"Co3O4")而提取用全名(如"Co3O4/CC"),归一化后"co3o4cc"不包含"co3o4"。其余是 FE/电势在 tolerance 边缘。

---

## 三、全流程架构与 SOP

### 3.1 概览数据流

```
[Gold Standard]                          [PDF文献 35篇]
Mydata22.0_1√(1).xlsx (310 rows)              │
        │                                MinerU 解析
        │                                ├── *.md
        │                                ├── *_content_list.json
        │                                └── *_middle.json
        │                                      │
        │                                [Text Extraction]
        │                                DeepSeek v4-flash × 35全文job
        │                                Prompt: 7.4KB竞赛版 (material_system_patches)
        │                                      │
        │                                [Image Extraction]
        │                                Qwen VLM × 507图像job
        │                                Prompt: 图表FE读数
        │                                      │
        │                           ┌──────────┴──────────┐
        │                           │                     │
        │                    raw text records      raw image records
        │                           │                     │
        │                           └──────────┬──────────┘
        │                                      │
        │                           [Schema Mapping] (03h)
        │                           DeepSeek v4-flash × 55 jobs
        │                           raw → Mydata 22字段格式
        │                           → 1029 mapped records
        │                                      │
        │                           ┌──────────┼──────────┐
        │                           │          │          │
        │                    ①pH修正   ②催化剂拆解  ③Unicode归一化
        │                           │          │          │
        │                    ④LLM形态  ⑤LLM载体   ⑥LLM负载量
        │                           │          │          │
        │                    ⑦DFT改性  ⑧VLM SEM   ⑨per-row修正
        │                           │          │          │
        │                           └──────────┼──────────┘
        │                                      │
        │                           final_v13_ph_fixed.json
        │                                      │
        └──────────────────┬───────────────────┘
                           │
                    [Judgement Engine]
                    build_final_judgement.py
                           │
              ┌────────────┼────────────┐
              │            │            │
        summary.md   rows.xlsx   rows.json
```

### 3.2 各环节 SOP

#### 环节 0: Gold 数据读取

**脚本**: `build_final_judgement.py` (内联)

**规则**:
- 读取 `Mydata22.0_1√(1).xlsx`, Sheet1
- col A 非空 → 用 col A 作为催化剂名
- col A 为空 + col B 非空 → 用 col B 作为催化剂名
- col A 和 col B 都为空 → 跳过该行
- 共 310 行有效数据

#### 环节 1: Catalyst Decomposition (催化剂拆解)

**脚本**: `goldenset_decompose_catalyst.py`

**规则**:
1. 识别 support: 匹配 `/CC`, `/CF`, `/NF`, `/TP`, `/TM`, `/CP`, `/SS`, `/PC` 等后缀 → 查表得载体元素
2. 识别 modifier: 
   - 含数字修饰: `Ag1.5Co` → Ag 是改性, Co 是活性
   - 连字符: `La-Co3O4` → La 是改性
   - 斜杠: `Ru/Cu2O` → Ru 是改性
   - @ 分隔: `Cu@ZnO` → Cu 是改性
3. 识别 active metal: 从化合物式取第一个金属元素
4. 查周期表 → 原子序数

**常见错误修复**:
- Co 被误认为 C: 两字母元素优先匹配
- Fe2O3 活性金属取 O: 排除非金属元素

#### 环节 2: Schema Mapping (原始格式转换)

**脚本**: `03h_run_api_schema_mapping.py`

**功能**: 将 raw records (catalyst_name_raw, faradaic_efficiency_raw, potential_raw, ...) 映射为 Mydata 22 字段格式。

**已知局限**:
- 催化剂名归一化时丢弃改性信息 (`Ru/Cu2O` → `Cu2O`)
- 自动推断 pH/负载量等字段 (应设为 None)
- 形态/载体 flags 不填充

#### 环节 3: pH 修正

**脚本**: `04_enrich_ph_from_evidence.py`

**规则** (按优先级):
1. pH_raw 已有显式值 → 直接使用
2. 电解质信号正则匹配 (0.1M NaOH→13, 1M KOH→14, 0.5M K2SO4→7, HCl→1)
3. PBS → 需看磷酸缓冲比例
4. 同文档传播 (text→image)
5. **0.1M 规则必须在 1M 规则前面** (防 `1` 误匹配 `0.1`)

#### 环节 4: 形态/载体提取

**脚本**: `run_llm_morphology_v2.py` + `run_vlm_morph.py`

**方法**:
- LLM (deepseek-chat): 每文档1次, 从 Experimental 段提取
- VLM (qwen-vl-max): 每张 SEM 图判断形态
- 图文合并: 一致→高置信度, 分歧→以文本为准

**标准词表**:
- 形态: nanowire / nanosheet / nanobelt / nanotube / nanorod / nanoparticle / nanosphere
- 载体: foam / mesh / fiber / foil

**后处理同义词**: flake→nanosheet, nanofiber→nanowire, nanoribbon→nanobelt, particle→nanoparticle

#### 环节 5: 负载量提取

**脚本**: `extract_modifier_mass_fraction.py`

**定义**: 负载量 = 改性元素质量分数 (wt%), 不是总负载量

**方法**: LLM 从 Experimental+SI 提取改性元素 wt% (ICP-OES/EDS)
- 纯催化剂 (无改性元素) → 本地填 0
- 有改性元素但找不到 wt% → 空

#### 环节 6: 改性方式判定

**脚本**: `extract_modification_type.py`

**方法**: LLM 从 DFT/Computational 段判断
- 掺杂(=1): 替换晶格原子 (substitutional doping)
- 负载(=0): 表面沉积/吸附 (surface decoration/adsorption)

#### 环节 7: Unicode 归一化

**内联代码**: `str.translate(SUB_MAP)` 将 ₀₁₂₃₄₅₆₇₈₉ → 0123456789

**后缀别名**: `NWs/C` → `/PC`, `PHNSs` → 去除, `NAs` → 去除

#### 环节 8: 匹配算法

**步骤**:
1. 催化剂名归一化 → 双向包含过滤
2. 电势 ±0.05V 过滤
3. FE ±0.12 过滤
4. 候选排序: (FE差, 元素重叠, 缺失数)
5. FE差 < 0.03 时, 优先选元素重叠最多的候选

#### 环节 9: 审判引擎

**脚本**: `build_final_judgement.py`

**判定逻辑** (逐字段):
- 证据支持 extraction, gold 不同 → `gold_likely_wrong`
- 证据支持 gold, extraction 不同 → `extraction_likely_wrong`
- 双方一致 → `content_correct`
- 数值等价 (VLM精度, 单位换算) → `numeric_equivalent`
- 多实验条件 → `multi_condition_not_error`
- 匹配不可靠 → `binding_uncertain`
- 无法判定 → `disputed_or_review`

**产物**:
- `final_judgement_summary.md` — 人读总结
- `final_judgement_rows.xlsx` — 逐行可筛选审计表 (颜色编码)
- `final_judgement_rows.json` — 证据链 JSON

---

## 四、关键文件索引

| 文件 | 路径 |
|------|------|
| Gold 数据 | `E:\fluent_agent\goldenset\Mydata22.0_1√(1).xlsx` |
| 最终提取结果 | `goldenset_nitrate_all/final_mapped_records.json` |
| 判决总结 | `goldenset_nitrate_all/final_judgement_summary.md` |
| 逐行审计表 | `goldenset_nitrate_all/final_judgement_rows.xlsx` |
| 证据链 JSON | `goldenset_nitrate_all/final_judgement_rows.json` |
| 全争议审计 | `goldenset_nitrate_all/full_dispute_audit.xlsx` |
| NO3 审计 | `goldenset_nitrate_all/NO3_audit_table.xlsx` |
| 系统演化+SOP | `goldenset_nitrate_all/SYSTEM_EVOLUTION_AND_SOP.md` |
| 字段提取 SOP | `goldenset_nitrate_all/GOLDENSET_SOP.md` |
| 交接文档 | `docs/goldenset_handoff_final_20260612.md` |

## 五、LLM 成本

| 步骤 | 次数 | 模型 |
|------|------|------|
| 文本提取 | 35 | deepseek-v4-flash |
| VLM 图像 | 507 | qwen3.7-plus |
| Schema Mapping | 55 | deepseek-v4-flash |
| 形态/载体 LLM | 34 | deepseek-chat |
| 负载量 LLM | 68 | deepseek-chat |
| 改性方式 DFT LLM | 21 | deepseek-chat |
| VLM SEM 形态 | 226 | qwen-vl-max |
| **总计** | **~950** | |
