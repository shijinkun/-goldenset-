# Goldenset Validation Package

## Extraction Target Fields (16 fields)

The system extracts the following structured data from electrocatalytic nitrate reduction literature:

| Category | Fields |
|----------|--------|
| Core identity | Catalyst name, Active component |
| Performance | Faradaic Efficiency (FE), Potential (V vs RHE) |
| Atomic numbers | Active metal atomic number |
| Reaction conditions | pH, Modification type (doping=1 / loading=0) |
| Support morphology | Porous foam, Mesh, Fiber/paper, Foil/plate |
| Catalyst morphology | Nanowire, Nanosheet, Nanoparticle, Nanosphere, Nanorod, Nanotube, Nanobelt |

## Validation Results

| Metric | Value |
|--------|-------|
| Gold standard rows | 310 |
| Extraction records | 1029 |
| Matched rows | 286 (92.3%) |
| **Average field compliance** | **94.3%** |

### Per-Field Compliance

| Field | Compliance | 
|-------|-----------|
| Catalyst name | 100% |
| FE | 100% |
| Potential | 100% |
| Nanorod | 100% |
| Active metal Z | 98% |
| Nanosphere | 97% |
| Nanobelt | 97% |
| Modification type | 95% |
| Active component | 95% |
| Support_mesh | 95% |
| Support_foil | 94% |
| Nanotube | 93% |
| pH | 93% |
| Support_foam | 92% |
| Nanowire | 91% |
| Nanosheet | 89% |
| Nanoparticle | 86% |

### Compliance Definition
A field value is considered compliant when:
- Extraction matches gold standard exactly, OR
- Extraction is supported by paper evidence while gold differs (gold labeling error), OR
- Values are numerically equivalent within tolerance

### Package Contents
-  — Gold standard (16 fields, 310 rows)
-  — Extracted data (16 fields, 1029 records)
-  — Per-row per-field audit table with evidence
-  — Judgement summary
-  — Full report with unmatched row analysis
-  — System pipeline and SOP
-  — Field extraction rules
-  — All-field dispute audit
